Reconocimiento

Se solicita a los usuarios que acceden a los datos a trav�s de la interfaz de b�squeda de registros en la Base de Datos de la RACM, sean tan amables de dar el cr�dito correspondiente en documentos, informes o cualquier otra publicaci�n y presentaci�n que incluya datos obtenidos de esta Red, sugiriendo el siguiente texto:
�Agradecemos  al Gobierno de la Ciudad de M�xico, a trav�s del  Instituto para la Seguridad de las Construcciones en la Ciudad de M�xico (ISC) y al Centro de Instrumentaci�n y Registro S�smico, A. C. (CIRES) por el apoyo para utilizar el acervo de datos de la Red Acelerogr�fica de la Ciudad de M�xico (RACM).�


Acknowledgments
Users which get acceleration records through the search interface of RACM Database, we kindly asked, you kindly give the corresponding acknowledgment in documents, reports or any other publication and presentation that includes data obtained of this Network, suggesting the following text:
"We thank the Government of Mexico City, through the Instituto para la Seguridad de las Construcciones en la Ciudad de M�xico (ISC) and the Centro de Instrumentaci�n y Registro S�smico, AC (CIRES) for the support to use the data collection of the Red Acelerogr�fica de la Ciudad de M�xico (RACM). "

